package com.example.demo.carts.repositories;

import com.example.demo.catalog.entity.ProductEntity;

public class CartRepositoryImpl implements CartRepository {

  @Override
  public int createCart(ProductEntity productEntity) {
    return 1;
  }
}
