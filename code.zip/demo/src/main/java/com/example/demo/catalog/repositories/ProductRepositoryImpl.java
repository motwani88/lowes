package com.example.demo.catalog.repositories;

import com.example.demo.catalog.entity.ProductEntity;

@Repository
public class ProductRepositoryImpl implements ProductRepository {

  @Override
  public ProductEntity[] getProducts() {
    return new ProductEntity[new ProductEntity(1,"PizzaA")];
  }
}
