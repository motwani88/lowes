package com.example.demo.catalog.repositories;

public interface ProductRepository {
  public ProductEntity[] getProducts();
}
