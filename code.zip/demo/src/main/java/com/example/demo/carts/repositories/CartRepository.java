package com.example.demo.carts.repositories;

import com.example.demo.catalog.entity.ProductEntity;

public interface CartRepository {
  public int createCart(ProductEntity productEntity);
}
