package com.example.demo.catalog.controllers;

import com.example.demo.catalog.dtos.ProductDto;
import com.example.demo.catalog.entity.ProductEntity;
import com.example.demo.catalog.mappers.ProductMapper;
import com.example.demo.catalog.services.ProductService;

@RestController
@RequestMapping("/products")
public class ProductController {

@Autowired
ProductService productService;

@Autowired
ProductMapper mapper;

  @GetMapping("/")
  public ResponseEntity getProducts() {
  ProductEntity[] products = productService.getProducts();
  ProductDto[] productDto = mapper.map(products);
  return new ResponseEntity(productDto);
  }
}
