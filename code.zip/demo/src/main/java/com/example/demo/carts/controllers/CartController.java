package com.example.demo.carts.controllers;

import com.example.demo.carts.mappers.CartMapper;
import com.example.demo.carts.services.CartService;
import com.example.demo.catalog.dtos.ProductDto;
import com.example.demo.catalog.entity.ProductEntity;
import com.example.demo.catalog.mappers.ProductMapper;
import com.example.demo.catalog.services.ProductService;
import sun.security.provider.certpath.OCSPResponse;

@RestController
@RequestMapping("/carts")
public class CartController {

@Autowired
CartService cartService;

@Autowired
ProductMapper productMapper;

  @PostMapping("/")
  public ResponseEntity createCart(ProductDto productDto) {
    ProductEntity productEntity = productMapper.mapBtoA(productDto);
  int result = cartService.createCart(productEntity);
  return new ResponseEntity(result);
  }
}
