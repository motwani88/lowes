package com.example.demo.catalog.entity;

@setter
@getter
public class ProductEntity {
  public int productId;
  public String name;
  public Toppings[] toppings;
}
