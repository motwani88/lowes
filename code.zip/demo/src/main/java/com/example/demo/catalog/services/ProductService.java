package com.example.demo.catalog.services;

import com.example.demo.catalog.repositories.ProductRepository;

@Service
public class ProductService {

@AutoWired
ProductRepository productRepository;

  public ProductEntity[] getProducts() {
    ProductEntity[] productEntities = productRepository.getProducts();
    return productEntities;
  }
}
