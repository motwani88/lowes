package com.example.demo.catalog.mappers;


import com.example.demo.catalog.dtos.ProductDto;
import com.example.demo.catalog.entity.ProductEntity;

public class ProductMapper extends ZebraMapper {

  public ProductDto mapAtoB(ProductEntity productEntity) {
     ProductDto dto = new ProductDto();
     dto.setProductId(productEntity.getProductId);
     dto.setName(productEntity.getName);
   }

  public ProductEntity mapBtoA(ProductDto productDto) {
    ProductEntity entity = new ProductEntity();
    entity.setProductId(productDto.getProductId);
    entity.setName(productDto.getName);
  }
}
