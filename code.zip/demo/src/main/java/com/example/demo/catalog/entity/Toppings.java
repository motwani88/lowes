package com.example.demo.catalog.entity;

public class Toppings {
  public int productId;
  public String name;
}
