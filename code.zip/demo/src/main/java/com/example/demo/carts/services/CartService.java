package com.example.demo.carts.services;

import com.example.demo.carts.repositories.CartRepository;
import com.example.demo.catalog.dtos.ProductDto;
import com.example.demo.catalog.entity.ProductEntity;
import com.example.demo.catalog.repositories.ProductRepository;

public class CartService {

@AutoWired
CartRepository cartRepository;

  public int createCart(ProductEntity productEntity) {
    int result = cartRepository.createCart(productEntity);
    return result;
  }
}
