package com.example.demo.catalog.dtos;

public class ProductDto {
  public int productId;
  public String name;
}
