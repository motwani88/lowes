Problem Statement
Create an Pizza store app that should be able to take care of following use cases:
 
Must Haves:
Shall allow the user to login to the application with valid credential

Shall allow the user to selects pizza from the available options. 
/products
/carts/{cartId}
Shall allow the user to order pizza
/orders/{ordersId}
Shall allow the user to select extra topping for the Piza
/carts/{cartId}
Shall allow the user to view the billing amounts
/orders/{ordersId}
Shall allow the user to make payment and place the order
/orders/{ordersId}/payments
Shall allow the user to cancel the order
/orders/{ordersId}/